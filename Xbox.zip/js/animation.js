// JavaScript Document

//getElementById shortcut
var El = function(a){
    return document.getElementById(a);
}// Detecting IE
var div = document.createElement("div");
div.innerHTML = "<!--[if lt IE 10]><i></i><![endif]-->";
var isIeLessThan10 = (div.getElementsByTagName("i").length == 1);
window.onload = function() {
    var stage = El("stage");
    var backup = El("backup");
    if (isIeLessThan10) {
        //show back up image
        stage.style.display='none';
        backup.style.display='block';
    } else {
        stage.style.display='block';
        yourAnim();
    }  
};

// your greensock animation here
function yourAnim() {


    var catchall = El("wrapper");
    var cta = El("ctaHit");
    var smoothStuff = ["#game01", "#game02", "#game03", "#game04", "#CTA", "#xBoxProduct"]; 
    var games = ['#game01', '#game02', '#game03', '#game04'];

    // pause, resume, restart buttons defined
    var pauseBtn = El("pauseBtn");
    var resumeBtn = El("resumeBtn");
    var restartBtn = El("restartBtn");

    CSSPlugin.defaultTransformPerspective = 500;
    TweenLite.ticker.fps(30);
    TweenLite.set("#stage",{perspective: 800, autoAlpha: 1});
    TweenLite.set(".game",{transformOrigin: "0% 0%"});
    TweenLite.set(games, {transformStyle: "preserve-3d"});
    TweenLite.set(["#copy1", "#copy2", "#copyEnd1", "#copyEnd2", "#offer-promo"], {transformOrigin: "50% 50%", autoAlpha: 0});

    var tl = new TimelineLite(); 
    //helps smooth animation in IE and FF
    tl.set(smoothStuff,{z: 1, transformStyle: "preserve-3d"});


    tl.addLabel("frame01");
    tl.from("#footer", 0.7, {y: 250, ease: Power3.easeOut}, "frame01");
    tl.fromTo("#copy_footer01", 0.5, {autoAlpha: 0},{autoAlpha: 1, ease: Linear.easeNone}, "frame01+=0.4");

    tl.fromTo("#copy1", 0.11, {immediateRender: false, autoAlpha: 0.3, force3D: true,  scale: 4}, {autoAlpha: 1, scale: 1.05, ease: Linear.easeNone}, "frame01+=0.1")
        .fromTo("#copy1", 2, {immediateRender: false, force3D: true,  scale: 1.05}, {scale: 1, ease: Power2.easeOut}, "frame01+=0.21");

    tl.staggerFrom(".staggerColor01", 0.6, {fill: "#111111", ease: Power2.easeOut}, 0.002, "frame01");
    tl.staggerTo(".staggerColor01", 0.6, {fill: 'rbga(256, 256, 256, 0)', ease: Power2.easeInOut}, 0.011, "frame01+=2.1");

    //GAME TRANSITIONS//////
    tl.addLabel("gameSeq", "-=0.9");


    //game 1 and logo in//////
    tl.set(games, {transformOrigin:'center center -60'}, 'gameSeq');

    tl.to("#game01", 0.1, {autoAlpha: 1, ease: Power2.easeIn}, "gameSeq+=0.65");
    tl.fromTo("#game01", 0.7, {zIndex: 3, force3D: true, rotationX: "+=90", x: "0"}, {zIndex: 4, force3D: true, rotationX: 0, x: "0", ease: Power4.easeInOut}, "gameSeq+=0.4");

    tl.from("#gmLogo01", 0.8, {force3D: true, y: "-=250px", ease: Power4.easeInOut}, "gameSeq+=0.4");


    tl.set("#game01", {className: "+=shadow"}, "gameSeq");

    //game 1 and logo out//////

    tl.fromTo("#game01", 0.6, {zIndex: 4, force3D: true, rotationX: '0'}, {zIndex: 3, force3D: true, rotationX: '-=90', ease: Power4.easeInOut}, "gameSeq+=1.9");
    tl.to("#gmLogo01", 0.6, {force3D: true, y: "+=250px", autoAlpha: 0, ease: Power4.easeInOut, }, "gameSeq+=1.9");
    tl.set("#game01", {autoAlpha: 0}, 'gameSeq+=2.6');

    //game 2 and logo in//////
    tl.fromTo("#game02", 0.6, {zIndex: 3, force3D: true, rotationX: '+=90'}, {zIndex: 4, force3D: true, rotationX: '0', ease: Power4.easeInOut}, "gameSeq+=1.9")
      .to("#game02", 0.2, {force3D: true, autoAlpha: 1, ease: Power4.easeInOut}, "gameSeq+=1.9");
    tl.from("#gmLogo02", 0.7, {force3D: true, y: "-=250px", autoAlpha: 0, ease: Power4.easeInOut}, "gameSeq+=1.9");


    tl.to("#copy_footer01", 0.5, {autoAlpha: 0, ease: Linear.easeNone}, "gameSeq+=1.9");
    tl.from("#copy_footer02", 0.5, {autoAlpha: 0, ease:Linear.easeNone}, "gameSeq+=1.9");

    //game 2 shadow//////
    tl.set("#game02", {className: "+=shadow"}, "gameSeq+=1.9");

    //game 2 and logo out//////

    tl.fromTo("#game02", 0.6, {zIndex: 4, rotationX: '0'}, {zIndex: 3, rotationX: '-=90', ease: Power4.easeInOut}, "gameSeq+=3.4");
    tl.to("#gmLogo02", 0.6, {force3D: true, y: "+=250px", autoAlpha: 0, ease: Power4.easeInOut}, "gameSeq+=3.4");
    tl.set("#game02", {autoAlpha: 0}, 'gameSeq+=4');

    tl.to("#copy_footer02", 0.5, {autoAlpha: 0, ease: Linear.easeNone}, "gameSeq+=3.4");
    tl.fromTo("#copy_footer01", 0.5, {autoAlpha: 0},{autoAlpha: 1, ease: Linear.easeNone}, "gameSeq+=3.4");

    //game 3 and logo in//////
    tl.fromTo("#game03", 0.6, {zIndex: 3, force3D: true, rotationX: '+=90'}, {zIndex: 4, force3D: true, rotationX: '0', ease: Power4.easeInOut}, "gameSeq+=3.4")
      .to("#game03", 0.2, {force3D: true, autoAlpha: 1, ease: Power4.easeInOut}, "gameSeq+=3.4");
    tl.from("#gmLogo03", 0.7, {force3D: true, y: "-=250px", autoAlpha: 0, ease: Power4.easeInOut}, "gameSeq+=3.4");

    tl.set("#game03", {className: "+=shadow"}, "gameSeq+=3.4");

    //game 3 and logo out//////

    tl.fromTo("#game03", 0.6, {zIndex: 4, force3D: true, rotationX: '0'}, {zIndex: 3, force3D: true, rotationX: '-=90', ease: Power4.easeInOut}, "gameSeq+=4.9");
    tl.to("#gmLogo03", 0.6, {force3D: true, y: "+=250px", autoAlpha: 0, ease: Power4.easeInOut}, "gameSeq+=4.9");
    tl.set("#game03", {force3D: true, autoAlpha: 0}, 'gameSeq+=5.9');

    //game 4 and logo in//////
    tl.fromTo("#game04", 0.6, {zIndex: 3, force3D: true, rotationX: '+=90'}, {zIndex: 4, force3D: true, rotationX: '0', ease: Power4.easeInOut}, "gameSeq+=4.9")
      .to("#game04", 0.2, {force3D: true, autoAlpha: 1, ease: Power4.easeInOut}, "gameSeq+=4.9");
    tl.from("#gmLogo04", 0.7, {force3D: true, y: "-=250px", autoAlpha: 0, ease: Power4.easeInOut}, "gameSeq+=4.9");

    //game 2 shadow//////
    tl.set("#game04", {className: "+=shadow"}, "gameSeq+=4.9");

    //game 4 and logo out//////
    tl.to("#game04", 0.12, {autoAlpha: 0, ease: Power2.easeIn}, "gameSeq+=6.65");
    tl.fromTo("#game04", 0.6, {zIndex: 4, force3D: true, rotationX: '0'}, {zIndex: 3, force3D: true, x: '-=10',  rotationX: '-=90', ease: Power4.easeInOut}, "gameSeq+=6.4");

    tl.to("#gmLogo04", 0.6, {force3D: true, y: "+=250px", autoAlpha: 0, ease: Power4.easeInOut}, "gameSeq+=6.4");
    //GAMES DONE//////

    tl.addLabel("frame02");


    //Jump ahead IN
    tl.fromTo("#copy2", 0.11, {immediateRender: false, autoAlpha: 0.3, force3D: true,  scale: 4}, {autoAlpha: 1, scale: 1.1, ease: Linear.easeNone}, "frame02")
        .fromTo("#copy2", 2, {immediateRender: false, force3D: true,  scale: 1.1}, {scale: 1, ease: Power2.easeOut}, "frame02+=0.11");
    tl.staggerFrom(".staggerColor02", 0.6, {fill: "#111111", ease: Power2.easeOut}, 0.002, "frame02");

    //Jump ahead OUT
    tl.staggerTo(".staggerColor02", 0.6, {force3D: true, fill: 'rbga(256, 256, 256, 0)', ease: Power2.easeInOut}, 0.011, "frame02+=2.2");
    tl.to("#copy_footer01", 0.6, {autoAlpha: 0, ease: Linear.easeNone}, "frame02+=2.1");


    ////END CARD////
    tl.addLabel("endCard", "-=0.5");

    //endcard bg color
    tl.fromTo("#footer", 1, {immediateRender: false, transformOrigin: "right bottom", scaleX: 1}, {scaleX: 1.5, ease: Power4.easeIn}, "endCard-=1")
    .fromTo("#footer", 0.2, {immediateRender: false, transformOrigin: "right bottom", scaleX: 1.5}, {scaleX: 3.4}, "endCard")
    .to("#footer", 1, {scaleY: 5, ease: Power3.easeOut}, "endCard+=0.2"); // this scaleY is the height of the banner divided by the height footer bar

    //out with the old and in with the new
    tl.fromTo(".xBoxLogo", 1.2, {immediateRender: false, scale: 1, autoAlpha: 0, y: "+=25"}, {autoAlpha: 1, y: "0", ease: Power3.easeOut}, "endCard+=0.2");
    tl.from("#logo_microsoft", 1.2, {autoAlpha: 0, y: "+=25", ease: Power3.easeOut}, "endCard+=0.2");

    //XBOX CONSOLE AND CONTROLLER
    tl.from("#xBoxProduct", 1.7, {force3D: true, y: "-=40", ease: Power4.easeOut}, "endCard+=0.4")
      .from("#xBoxProduct", 0.6, {autoAlpha: 0, ease: Power2.easeInOut}, "endCard+=0.4");

    tl.from("#console", 2, {
            ease: Power3.easeOut
    }, "endCard+=0.5");

    tl.from("#controller", 2, {
            y: "-=20",
            ease: Power3.easeOut
    }, "endCard+=0.5");
    //end xbox console and controller

    //XboxOne Bundle Headline
    tl.fromTo("#offer-promo", 0.11, {immediateRender: false, autoAlpha: 0.1, force3D: true,  scale: 10}, {autoAlpha: 1, scale: 1.1, ease: Linear.easeNone}, "endCard+=0.9")
        .fromTo("#offer-promo", 1.6, {immediateRender: false, force3D: true,  scale: 1.1}, {scale: 1, ease: Power2.easeOut}, "endCard+=1.01");
    //tl.staggerFrom(".staggerColor04", 1, {fill: "#666666", ease: Power2.easeOut}, 0.012, "endCard+=1");



    //Now starting at
    tl.fromTo("#copyEnd1", 0.11, {immediateRender: false, autoAlpha: 0.3, force3D: true,  scale: 3}, {autoAlpha: 1, scale: 1.1, ease: Linear.easeNone}, "endCard+=1.5")
        .fromTo("#copyEnd1", 1, {immediateRender: false, force3D: true,  scale: 1.1}, {scale: 1, ease: Power2.easeOut}, "endCard+=1.61");

    tl.fromTo("#copyEnd2", 0.11, {immediateRender: false, autoAlpha: 0.3, force3D: true,  scale: 4}, {autoAlpha: 1, scale: 1.1, ease: Linear.easeNone}, "endCard+=1.8")
        .fromTo("#copyEnd2", 1.6, {immediateRender: false, force3D: true,  scale: 1.1}, {scale: 1, ease: Power2.easeOut}, "endCard+=1.91");

    //tl.staggerFrom(".staggerColor03", 0.3, {fill: "#666666", ease: Power2.easeOut}, 0.012, "endCard+=1.9");



    TweenLite.set(["#ctaBG_dark", "#ctaCopy"], {transformOrigin: "50% 50%"}); 

    //CTA
    tl.from("#ctaBody", 0.7, {y:"-=20", autoAlpha: 0, ease: Power4.easeOut}, "endCard+=1.91");


    console.log(tl.totalDuration());
    //interactivity



    // pause, resume, restart buttons actions
    pauseBtn.onclick = function() {
        tl.pause();
    };
    resumeBtn.onclick = function() {
        tl.resume();
    };
    restartBtn.onclick = function() {
        tl.restart();
    };

    // cta.addEventListener("click", function(){
    //     window.adKit.clickCTA();
    // });

    cta.addEventListener("mouseover", function(){
        //console.log("CTAover");
        TweenLite.to("#ctaBG_dark", 0.4, {fill: "white", scale: 1.04, ease: Power3.easeOut});
        TweenLite.to("#ctaCopy", 0.4, {force3D: true,  scale: 1.1, ease: Power3.easeOut});
        TweenLite.to(".ctaTextColor", 0.4, {fill: "#212223", ease: Power3.easeOut});
    });

    cta.addEventListener("mouseout", function(){
        //console.log("CTAout");
        TweenLite.to("#ctaBG_dark", 0.4, {fill: "#212223", scale: 1, ease: Power3.easeOut});
        TweenLite.to("#ctaCopy", 0.4, {force3D: true,  scaleX: 1.001,  scaleY: 1, ease: Power3.easeOut});
        TweenLite.to(".ctaTextColor", 0.4, {fill: "#ffffff", ease: Power3.easeOut});
    });

    // catchall.addEventListener("click", function(){
    //     window.adKit.clickCatchAll();
    // });

};