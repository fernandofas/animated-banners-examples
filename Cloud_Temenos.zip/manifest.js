FT.manifest({
	"filename":"index.html",
	"width":970,
	"height":66,
	"clickTagCount":1,
    "videos": [{"name": "video1", "ref": "57106/121229_Cloud_Temenos_WE_315x179"}],
	"expand":{
		"fullscreen":false,
		"width":970,
		"height":250,
		"indentAcross":0,
		"indentDown":0
	}
});