/////////// Video and Controls /////////////
vid = myFT.$("#vid");
video_play = myFT.$("#video_play"),
video_pause = myFT.$("#video_pause"),
videoReplay = myFT.$("#videoReplay"),
sound_off = myFT.$("#sound_off"),
sound_on = myFT.$("#sound_on");

video_play.on("click", function() {
vid[0].play();
video_pause.css("visibility", "visible");
video_play.css("visibility", "hidden");
});

video_pause.on("click", function() {
vid[0].pause();
video_pause.css("visibility", "hidden");
video_play.css("visibility", "visible");
});

videoReplay.on("click", function() {
vid[0].restart();
videoReplay.css("visibility", "hidden");
video_pause.css("visibility", "visible");
sound_off.css("visibility", "visible");
vid[0].muted = true;
});

sound_off.on("click", function() {
vid[0].muted = false;
sound_off.css("visibility", "hidden");
sound_on.css("visibility", "visible");
});

sound_on.on("click", function() {
vid[0].muted = true;
sound_on.css("visibility", "hidden");
sound_off.css("visibility", "visible");
});

vid.on("ended", function() {
videoReplay.css("visibility", "visible");
sound_on.css("visibility", "hidden");
sound_off.css("visibility", "hidden");
video_pause.css("visibility", "hidden");
video_play.css("visibility", "hidden");
console.log("VID ENDED");
});

/////////// Expand and Collapse /////////////
var unexpanded = myFT.$("#unexpanded"),
expanded = myFT.$("#expanded"),
wrapper = myFT.$("#wrapper"),
close = myFT.$("#close"),

expand = function(){
unexpanded.css("display", "none");
expanded.css("display", "block");
myFT.expand();
expandAnim.play(0); 
vid[0].muted = true;
},
    
contract = function(e){
expandAnim.kill();
expanded.css("display", "none");
unexpanded.css("display", "block");
if(e && e.type) {
myFT.contract();
}
    
contractAnim.play(0);
vid[0].stop();
vid.css("opacity", "0");
videoReplay.css("visibility", "hidden");
sound_on.css("visibility", "hidden");
sound_off.css("visibility", "hidden");
video_pause.css("visibility", "hidden");
video_play.css("visibility", "hidden");
};
    
myFT.on("contract", contract);

myFT.applyButton(unexpanded, expand);
myFT.applyClickTag(wrapper);
myFT.applyButton(close, function(){myFT.contract()});

wrapper.on("click", function() {
contract();
});
    
onload = function() {
    expand();
  }

/////////////////// Collapse Animation /////////////////////

CSSPlugin.defaultTransformPerspective = 1000;
var contractAnim = new TimelineLite();
contractAnim.from("#tile_01", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationY:90, perspective:500}, .25)
    .from("#tile_02", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationX:90, perspective:500}, 1)
    .from("#tile_03", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationX:90, perspective:500}, .75)

    .from("#tile_04", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationX:90, perspective:500}, .65)
    .from("#tile_05", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationX:90, perspective:500}, 0)
    .from("#tile_06", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationX:90, perspective:500}, .35)

    .from("#tile_07", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationX:90, perspective:500}, 1.20)
    .from("#tile_08", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationY:90, perspective:500}, .50)
    .from("#tile_09", .25, {z: 0.1, rotationZ: 0.01, force3D:true, rotationX:90, perspective:500}, 1.10)

    .to("#tileContainer", .75, {scaleX:4, scaleY:4, y:56, x:1500, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_01", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_02", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_03", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_04", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_05", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_06", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_07", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_08", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)
    .to("#tile_09", .75, {alpha:0, ease:Cubic.easeInOut}, 1.5)

    .to("#hero", .75, {z: 0.1, rotationZ: 0.01, force3D:true, alpha:1, scaleX:"2", scaleY:"2", y:0, x:"150", ease:Cubic.easeInOut}, 1.5)
    .to("#logo", .50, {alpha:1, ease:Cubic.easeOut}, 3)
    .to("#overlay", .50, {alpha:.50, ease:Quint.easeIn}, 4)
    .from("#cta", .50, {y: "5", alpha: 0}, 5.25)

    .from("#f1_copy1", .50, {alpha:0, y: "5"}, 4.25)
    .from("#hero2", 2, {x: 800, alpha: 0, ease:Quint.easeIn}, 5)
    .to("#f1_copy1", .50, {alpha:0}, 7)

    .from("#f2_copy1", .50, {alpha:0, y: "5"}, 7.25)
    .to("#f2_copy1", .50, {alpha:0}, 10.75)
    .to("#overlay", .50, {alpha:.50, ease:Quint.easeIn}, 10.75)
    .from("#f3_copy1", .50, {alpha:0, y: "5"}, 11)
    ;

var cta = document.getElementById("cta");

cta.onmouseover = function(){
    TweenLite.to(cta, .50, {y:"-5", ease:Cubic.easeOut});
}

cta.onmouseout = function(){
    TweenLite.to(cta, .50, {y:"0", ease:Cubic.easeOut});
}

////////////////// Expand Animation /////////////////////
CSSPlugin.defaultTransformPerspective = 1000;
var expandAnim = new TimelineLite( {paused: true} );
    expandAnim.from("#level_0", 1.25, {z: 0.1, rotationZ: 0.01, force3D:true, x: "-275", alpha:0, ease:Cubic.easeOut}, 0)
    .from("#level_1", 1.25, {z: 0.1, rotationZ: 0.01, force3D:true, x: "-175", alpha:0, ease:Cubic.easeOut}, 0)
    .from("#level_2", 1.25, {z: 0.1, rotationZ: 0.01, force3D:true, x: "-75", alpha:0, ease:Cubic.easeOut}, 0)
    .from("#level_3", 1.25, {z: 0.1, rotationZ: 0.01, force3D:true, x: "-70", alpha:0, ease:Cubic.easeOut}, 0)
    .from("#level_4", 1, {z: 0.1, rotationZ: 0.01, force3D:true, x: "-50", alpha:0, ease:Cubic.easeOut}, 0)
    .from("#level_5", 1, {z: 0.1, rotationZ: 0.01, force3D:true, x: "-20", alpha:0, ease:Cubic.easeOut}, 0)
    .from("#bg", 1.5, {z: 0.1, rotationZ: 0.01, force3D:true, x: "30", alpha:0, ease:Cubic.easeOut}, 0)
    .from("#hero3", 1.5, {z: 0.1, rotationZ: 0.01, force3D:true, delay: 1, scaleX: 0, scaleY: 0, x:20, ease:Cubic.easeOut, onComplete:expandComplete}, 0)
    
    .from("#f4_copy1", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0, y: "5"}, 3)
	.from("#f4_copy2", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0, y: "5"}, 3.50)

	.to("#f4_copy1", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0}, 7)
	.to("#f4_copy2", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0}, 7)

	.from("#f5_copy1", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0, y: "5"}, 8.25)
	.from("#f5_copy2", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0, y: "5"}, 8.75)
	
	.to("#f5_copy1", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0}, 12.75)
	.to("#f5_copy2", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0}, 12.75)
	.to("#overlay", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:1}, 12.75)

	.from("#f6_copy1", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0, y: "5"}, 14)
	.from("#f6_copy2", .50, {z: 0.1, rotationZ: 0.01, force3D:true, opacity:0, y: "5"}, 14.50)

    .from("#cta2", .50, {z: 0.1, rotationZ: 0.01, force3D:true, y: "5", opacity: 0}, 4.5);

//total time of banner
console.log(expandAnim.totalDuration());	
    
var wrapper = document.getElementById("wrapper");

wrapper.onmouseover = function(){
    TweenLite.to(cta2, .50, {y:"-5", opacity:1,  ease:Cubic.easeOut});
}

wrapper.onmouseout = function(){
    TweenLite.to(cta2, .50, {y:"0", opacity:1, ease:Cubic.easeOut});
}

function expandComplete(){
    document.getElementById('vid').style.opacity='1';
    document.getElementById('video_pause').style.visibility='visible';
    document.getElementById('sound_off').style.visibility='visible';
    vid[0].play();
}